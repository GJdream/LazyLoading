//
//  ViewController.m
//
//

@protocol ImageDownloaderDelegate;

@interface ImageDownloader : NSObject {
    id <ImageDownloaderDelegate> delegate;
    NSString *imageURLString;
    NSIndexPath *indexPathInTableView;
    NSMutableData *activeDownload;
    NSURLConnection *imageConnection;
    UIImage *downloadedImage;
}

@property(nonatomic, retain) NSIndexPath *indexPathInTableView;
@property(nonatomic, assign) id <ImageDownloaderDelegate> delegate;
@property(nonatomic, retain) NSMutableData *activeDownload;
@property(nonatomic, retain) NSURLConnection *imageConnection;
@property(nonatomic, retain) UIImage *downloadedImage;
@property(nonatomic, retain) NSString *imageURLString;

- (void)startDownload;
- (void)cancelDownload;

@end

@protocol ImageDownloaderDelegate

- (void)imageDidLoad:(NSIndexPath *)indexPath;

@end